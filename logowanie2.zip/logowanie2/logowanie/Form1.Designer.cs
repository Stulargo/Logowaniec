﻿namespace logowanie
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Zaloguj = new Button();
            Logowanie = new Label();
            LoginBox = new TextBox();
            pictureBox1 = new PictureBox();
            Login = new Label();
            Haslo = new Label();
            HasloBox = new TextBox();
            wynik = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Zaloguj
            // 
            Zaloguj.BackColor = SystemColors.ScrollBar;
            Zaloguj.Font = new Font("Segoe UI", 25F);
            Zaloguj.Location = new Point(454, 340);
            Zaloguj.Name = "Zaloguj";
            Zaloguj.Size = new Size(264, 58);
            Zaloguj.TabIndex = 0;
            Zaloguj.Text = "Zaloguj";
            Zaloguj.UseVisualStyleBackColor = false;
            Zaloguj.Click += button1_Click;
            // 
            // Logowanie
            // 
            Logowanie.AutoSize = true;
            Logowanie.Font = new Font("Segoe UI", 32.75F, FontStyle.Bold);
            Logowanie.Location = new Point(287, 9);
            Logowanie.Name = "Logowanie";
            Logowanie.Size = new Size(252, 60);
            Logowanie.TabIndex = 1;
            Logowanie.Text = "Logowanie";
            Logowanie.Click += label1_Click;
            // 
            // LoginBox
            // 
            LoginBox.BackColor = SystemColors.ActiveCaption;
            LoginBox.Font = new Font("Segoe UI", 25F);
            LoginBox.Location = new Point(454, 125);
            LoginBox.Name = "LoginBox";
            LoginBox.Size = new Size(264, 52);
            LoginBox.TabIndex = 2;
            LoginBox.TextChanged += LoginBox_TextChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(43, 113);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(213, 194);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_1;
            // 
            // Login
            // 
            Login.AutoSize = true;
            Login.BackColor = SystemColors.ButtonFace;
            Login.FlatStyle = FlatStyle.Flat;
            Login.Font = new Font("Segoe UI Semibold", 24.75F, FontStyle.Bold, GraphicsUnit.Point, 238);
            Login.Location = new Point(287, 132);
            Login.Name = "Login";
            Login.Size = new Size(104, 45);
            Login.TabIndex = 4;
            Login.Text = "Login";
            Login.Click += Login_Click;
            // 
            // Haslo
            // 
            Haslo.AutoSize = true;
            Haslo.BackColor = SystemColors.ButtonFace;
            Haslo.FlatStyle = FlatStyle.Flat;
            Haslo.Font = new Font("Segoe UI Semibold", 24.75F, FontStyle.Bold, GraphicsUnit.Point, 238);
            Haslo.Location = new Point(287, 234);
            Haslo.Name = "Haslo";
            Haslo.Size = new Size(105, 45);
            Haslo.TabIndex = 6;
            Haslo.Text = "Hasło";
            Haslo.Click += label1_Click_1;
            // 
            // HasloBox
            // 
            HasloBox.BackColor = SystemColors.ActiveCaption;
            HasloBox.Font = new Font("Segoe UI", 25F);
            HasloBox.Location = new Point(454, 231);
            HasloBox.Name = "HasloBox";
            HasloBox.Size = new Size(264, 52);
            HasloBox.TabIndex = 5;
            HasloBox.TextChanged += textBox1_TextChanged;
            // 
            // wynik
            // 
            wynik.AutoSize = true;
            wynik.Font = new Font("Segoe UI", 25F);
            wynik.Location = new Point(82, 352);
            wynik.Name = "wynik";
            wynik.Size = new Size(0, 46);
            wynik.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(790, 450);
            Controls.Add(wynik);
            Controls.Add(Haslo);
            Controls.Add(HasloBox);
            Controls.Add(Login);
            Controls.Add(pictureBox1);
            Controls.Add(LoginBox);
            Controls.Add(Logowanie);
            Controls.Add(Zaloguj);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Zaloguj;
        private Label Logowanie;
        private TextBox LoginBox;
        private PictureBox pictureBox1;
        private Label Login;
        private Label Haslo;
        private TextBox HasloBox;
        private Label wynik;
    }
}
