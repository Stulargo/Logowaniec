namespace Logowanie
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
             string storedUsername = login.Text;
             string storedPassword = haslo.Text;
            if (storedUsername == "admin" && storedPassword == "password123")
            {
                MessageBox.Show("Zalogowano pomy�lnie!");
            }
            else
            {
                MessageBox.Show("B��dny login lub has�o");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

    }
}
