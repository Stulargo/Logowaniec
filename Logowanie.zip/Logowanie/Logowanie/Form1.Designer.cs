﻿namespace Logowanie
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            zaloguj = new Button();
            login = new TextBox();
            haslo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // zaloguj
            // 
            zaloguj.Location = new Point(401, 217);
            zaloguj.Name = "zaloguj";
            zaloguj.Size = new Size(75, 23);
            zaloguj.TabIndex = 0;
            zaloguj.Text = "Zaloguj";
            zaloguj.UseVisualStyleBackColor = true;
            zaloguj.Click += button1_Click;
            // 
            // login
            // 
            login.Location = new Point(301, 144);
            login.Name = "login";
            login.Size = new Size(175, 23);
            login.TabIndex = 1;
            login.TextChanged += textBox1_TextChanged;
            // 
            // haslo
            // 
            haslo.Location = new Point(301, 188);
            haslo.Name = "haslo";
            haslo.Size = new Size(175, 23);
            haslo.TabIndex = 2;
            haslo.TextChanged += textBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(301, 126);
            label1.Name = "label1";
            label1.Size = new Size(68, 15);
            label1.TabIndex = 3;
            label1.Text = "Wpisz login";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(301, 170);
            label2.Name = "label2";
            label2.Size = new Size(69, 15);
            label2.TabIndex = 4;
            label2.Text = "Wpisz hasło";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 78);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(229, 208);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 22.5F, FontStyle.Bold);
            label4.Location = new Point(301, 9);
            label4.Name = "label4";
            label4.Size = new Size(171, 41);
            label4.TabIndex = 7;
            label4.Text = "Logowanie";
            label4.Click += label4_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(pictureBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(haslo);
            Controls.Add(login);
            Controls.Add(zaloguj);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button zaloguj;
        private TextBox login;
        private TextBox haslo;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label4;
    }
}
